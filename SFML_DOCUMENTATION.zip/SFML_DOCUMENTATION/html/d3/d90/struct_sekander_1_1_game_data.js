var struct_sekander_1_1_game_data =
[
    [ "assets", "d3/d90/struct_sekander_1_1_game_data.html#a2540773e72a9b18686041a4b626fd90f", null ],
    [ "input", "d3/d90/struct_sekander_1_1_game_data.html#afe024ef371741c95bad3abaf8ddeebf1", null ],
    [ "machine", "d3/d90/struct_sekander_1_1_game_data.html#a6f701ff9c5018ee293869248798f02a4", null ],
    [ "manager", "d3/d90/struct_sekander_1_1_game_data.html#a5d4bea0451d09e81fee2b4c38c2b6ca5", null ],
    [ "window", "d3/d90/struct_sekander_1_1_game_data.html#a01dc93a762f8235e2e95eb2c79fa25fc", null ]
];