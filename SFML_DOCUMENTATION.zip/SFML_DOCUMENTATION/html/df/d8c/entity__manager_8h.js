var entity__manager_8h =
[
    [ "Sekander::EntityManager", "d9/dee/class_sekander_1_1_entity_manager.html", "d9/dee/class_sekander_1_1_entity_manager" ],
    [ "shape_options", "df/d8c/entity__manager_8h.html#aed8eb219f4685b29738464e9f32c5d94", [
      [ "Square", "df/d8c/entity__manager_8h.html#aed8eb219f4685b29738464e9f32c5d94ae1827bea553b36ce0bbc7cddd6c57621", null ],
      [ "Circle", "df/d8c/entity__manager_8h.html#aed8eb219f4685b29738464e9f32c5d94acafcba9574f3415e8e9f6f194a6cb869", null ]
    ] ]
];