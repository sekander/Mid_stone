var _game_8hpp =
[
    [ "Sekander::GameData", "d3/d90/struct_sekander_1_1_game_data.html", "d3/d90/struct_sekander_1_1_game_data" ],
    [ "Sekander::Game", "d1/d46/class_sekander_1_1_game.html", "d1/d46/class_sekander_1_1_game" ],
    [ "GameDataRef", "d2/d07/_game_8hpp.html#a1d69b002ba2d23020901c28f0def5e16", null ]
];