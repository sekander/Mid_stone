var class_map_layer =
[
    [ "MapLayer", "db/d40/class_map_layer.html#ac1b9f1e3ba6d800abf508fa11490187b", null ],
    [ "~MapLayer", "db/d40/class_map_layer.html#a79858f9ee05242aa47ac680940e5ea74", null ],
    [ "MapLayer", "db/d40/class_map_layer.html#af323ddae8da169a64be1e0c216034397", null ],
    [ "getColor", "db/d40/class_map_layer.html#a6ecfbaf968ac9e6e4f814a30aa0c0f30", null ],
    [ "getGlobalBounds", "db/d40/class_map_layer.html#ab0df69c31bcaa781305ffbabd5de2c93", null ],
    [ "getTile", "db/d40/class_map_layer.html#a347375abb72832ea3362ba0d29898f30", null ],
    [ "operator=", "db/d40/class_map_layer.html#af9ffb2975916c0954ecf834642cb04b0", null ],
    [ "setColor", "db/d40/class_map_layer.html#a4dad5e08a823925292846664ce42657d", null ],
    [ "setTile", "db/d40/class_map_layer.html#a1152792435a0fa6203f6c3a038b93778", null ],
    [ "update", "db/d40/class_map_layer.html#a0f7690e23ecfde7a7dc6629f9df65635", null ]
];