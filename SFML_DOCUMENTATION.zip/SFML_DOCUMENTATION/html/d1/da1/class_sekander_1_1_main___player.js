var class_sekander_1_1_main___player =
[
    [ "Main_Player", "d1/da1/class_sekander_1_1_main___player.html#a3db6385e3bff1d503b9305dd51952371", null ],
    [ "Main_Player", "d1/da1/class_sekander_1_1_main___player.html#ad4c368b23e2e27a965a71dd5b5a9b8ba", null ],
    [ "Camera", "d1/da1/class_sekander_1_1_main___player.html#ac11f979e3ea8f386e0997336670e740b", null ],
    [ "CheckCollision", "d1/da1/class_sekander_1_1_main___player.html#aa204098b85f3075555557e167ab87f82", null ],
    [ "Dash", "d1/da1/class_sekander_1_1_main___player.html#a2745801e5bd672d995a5fda6046535e4", null ],
    [ "DoubleJump", "d1/da1/class_sekander_1_1_main___player.html#af62bb952d58130e6c79bf033c183df20", null ],
    [ "Draw", "d1/da1/class_sekander_1_1_main___player.html#a2db8b47f870a130057f550d7edeca43b", null ],
    [ "GetHealth", "d1/da1/class_sekander_1_1_main___player.html#a0da136e5dceaffa007560dbb08784d69", null ],
    [ "GetPosition", "d1/da1/class_sekander_1_1_main___player.html#a8177402b385700b10772b069e5b94913", null ],
    [ "Jump", "d1/da1/class_sekander_1_1_main___player.html#a5d37beaabf93f7c5b01578334da246a2", null ],
    [ "MoverDown", "d1/da1/class_sekander_1_1_main___player.html#a72cd2d23a9d43627df23bf791d5fe08c", null ],
    [ "MoverLeft", "d1/da1/class_sekander_1_1_main___player.html#a65ef67033301fad1550350ee12ae32d3", null ],
    [ "MoverRigtht", "d1/da1/class_sekander_1_1_main___player.html#a5207bda5738aefb2d905170545f6e373", null ],
    [ "MoverUp", "d1/da1/class_sekander_1_1_main___player.html#aaa5aa69d0e4947e24d3ea326f7142bc5", null ],
    [ "NU_Shooting", "d1/da1/class_sekander_1_1_main___player.html#a870cb1809cf55fa050558d40c2d6f487", null ],
    [ "PickUpGun", "d1/da1/class_sekander_1_1_main___player.html#aba0b538754bced9c11d7628d0a5096dd", null ],
    [ "Player_get_velocity_Y", "d1/da1/class_sekander_1_1_main___player.html#af7c8219ebab4cfcfaac1249dd483315c", null ],
    [ "Player_t00k_damange", "d1/da1/class_sekander_1_1_main___player.html#a8d52cc440a3fb8794354930c56cff539", null ],
    [ "Shooting", "d1/da1/class_sekander_1_1_main___player.html#aa2903bcbdbbc88119626429a882b7ab0", null ],
    [ "Shooting", "d1/da1/class_sekander_1_1_main___player.html#a6fa31e322512055913aa49032761f2c6", null ],
    [ "Update", "d1/da1/class_sekander_1_1_main___player.html#ae274e228df0f1d40f87e7bf4c83c5c89", null ]
];