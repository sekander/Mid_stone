var searchData=
[
  ['newedge_0',['newEdge',['../d9/dee/class_sekander_1_1_entity_manager.html#ab5c80c9646fea25cb0ab110a4ac51d38',1,'Sekander::EntityManager::newEdge(std::string name)'],['../d9/dee/class_sekander_1_1_entity_manager.html#a0debb38e1fb1e88d3d4e5af522e80b90',1,'Sekander::EntityManager::newEdge(std::string, float, float, float, float)']]],
  ['nu_5fshooting_1',['NU_Shooting',['../d1/da1/class_sekander_1_1_main___player.html#a870cb1809cf55fa050558d40c2d6f487',1,'Sekander::Main_Player']]]
];
