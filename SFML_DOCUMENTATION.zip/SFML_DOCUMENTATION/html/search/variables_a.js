var searchData=
[
  ['window_0',['window',['../d3/d90/struct_sekander_1_1_game_data.html#a01dc93a762f8235e2e95eb2c79fa25fc',1,'Sekander::GameData']]],
  ['world_1',['world',['../d1/da9/class_sekander_1_1_entity.html#a6c88c4e735203734409fdd7b1eddca39',1,'Sekander::Entity']]]
];
