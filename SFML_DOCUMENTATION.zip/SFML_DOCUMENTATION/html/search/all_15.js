var searchData=
[
  ['x_5fframes_5f1_0',['X_FRAMES_1',['../df/d44/_d_e_f_i_n_i_t_i_o_n_s_8hpp.html#a59c1849a23db0716bc2c2de300c35f1a',1,'DEFINITIONS.hpp']]],
  ['x_5fframes_5f2_1',['X_FRAMES_2',['../df/d44/_d_e_f_i_n_i_t_i_o_n_s_8hpp.html#a47eae7a523c04d9836507102716e0281',1,'DEFINITIONS.hpp']]],
  ['x_5fframes_5f3_2',['X_FRAMES_3',['../df/d44/_d_e_f_i_n_i_t_i_o_n_s_8hpp.html#af9bdb6427c8fdc0a878037fcb2e163b5',1,'DEFINITIONS.hpp']]]
];
