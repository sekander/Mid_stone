var searchData=
[
  ['radtodeg_0',['RADTODEG',['../df/d44/_d_e_f_i_n_i_t_i_o_n_s_8hpp.html#a9fcbc53371e9a60b983c6b338537aa40',1,'DEFINITIONS.hpp']]]
];
