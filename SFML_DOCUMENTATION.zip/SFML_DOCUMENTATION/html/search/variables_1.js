var searchData=
[
  ['body_0',['body',['../d1/da9/class_sekander_1_1_entity.html#a61bec1a7b77dd9b5e08c0908566450d4',1,'Sekander::Entity']]],
  ['bodydef_1',['bodyDef',['../d1/da9/class_sekander_1_1_entity.html#af8218d721852341a99eb08ee8ead53ff',1,'Sekander::Entity']]]
];
