var searchData=
[
  ['gamedataref_0',['GameDataRef',['../d8/d6a/namespace_sekander.html#a1d69b002ba2d23020901c28f0def5e16',1,'Sekander']]]
];
