var searchData=
[
  ['active_0',['active',['../d1/da9/class_sekander_1_1_entity.html#a6bd181c05edd3e27fa18efdd5dab2895',1,'Sekander::Entity']]],
  ['assets_1',['assets',['../d3/d90/struct_sekander_1_1_game_data.html#a2540773e72a9b18686041a4b626fd90f',1,'Sekander::GameData']]]
];
