var searchData=
[
  ['jump_0',['Jump',['../d4/d7c/class_sekander_1_1_enemy.html#a8f28e7a9f1fa9f039ea780e741683f14',1,'Sekander::Enemy::Jump()'],['../d1/da1/class_sekander_1_1_main___player.html#a5d37beaabf93f7c5b01578334da246a2',1,'Sekander::Main_Player::Jump()']]]
];
