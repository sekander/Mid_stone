var searchData=
[
  ['shape_5foptions_0',['shape_options',['../d8/d6a/namespace_sekander.html#aed8eb219f4685b29738464e9f32c5d94',1,'Sekander']]]
];
