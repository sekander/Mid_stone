var searchData=
[
  ['magik_5ffilepath_0',['MAGIK_FILEPATH',['../df/d44/_d_e_f_i_n_i_t_i_o_n_s_8hpp.html#aa8ed31a587192401b0614d619133ca6b',1,'DEFINITIONS.hpp']]],
  ['main_5fmenu_5fbackground_5ffilepath_1',['MAIN_MENU_BACKGROUND_FILEPATH',['../df/d44/_d_e_f_i_n_i_t_i_o_n_s_8hpp.html#a04cda72602d3ae59216d8aff93ea9b6a',1,'DEFINITIONS.hpp']]]
];
