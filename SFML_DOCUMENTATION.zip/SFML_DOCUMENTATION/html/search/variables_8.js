var searchData=
[
  ['shape_0',['shape',['../d1/da9/class_sekander_1_1_entity.html#a51d32e27f0af3c9f1d68cc27117310ad',1,'Sekander::Entity']]],
  ['socket_1',['socket',['../dd/d6a/class_sekander_1_1_game_over_state.html#a664bfe46410e08bd6a9d399ac3e79dc3',1,'Sekander::GameOverState']]]
];
