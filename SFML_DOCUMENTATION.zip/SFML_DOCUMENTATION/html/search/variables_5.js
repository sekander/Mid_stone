var searchData=
[
  ['groupid_0',['groupId',['../d1/da9/class_sekander_1_1_entity.html#a877b3b7b7b81c7e11cb174d1a4fc3b85',1,'Sekander::Entity']]]
];
