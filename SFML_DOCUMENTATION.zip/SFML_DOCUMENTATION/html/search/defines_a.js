var searchData=
[
  ['time_5fbefore_5fgame_5fover_5fappears_0',['TIME_BEFORE_GAME_OVER_APPEARS',['../df/d44/_d_e_f_i_n_i_t_i_o_n_s_8hpp.html#a0b73c5aa67be999a8922f4ddfce6e4a9',1,'DEFINITIONS.hpp']]]
];
