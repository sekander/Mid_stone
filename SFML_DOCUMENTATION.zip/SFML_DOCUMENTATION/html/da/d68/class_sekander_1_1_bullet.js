var class_sekander_1_1_bullet =
[
    [ "Bullet", "da/d68/class_sekander_1_1_bullet.html#aa01f203963a28b68470ad288d1fd37f7", null ],
    [ "Bullet", "da/d68/class_sekander_1_1_bullet.html#a003f538d802703d9a85898f4c7c9aabd", null ],
    [ "Get_Name", "da/d68/class_sekander_1_1_bullet.html#a0014d85f72f42816b9e095c4d2fe8199", null ],
    [ "Get_X_POS", "da/d68/class_sekander_1_1_bullet.html#a149639cae1ad1f688a3ba3fcef0b3985", null ],
    [ "Get_Y_POS", "da/d68/class_sekander_1_1_bullet.html#a2ba3aa653350110aad9552b3b7b9d4a5", null ],
    [ "IsBulletAlive", "da/d68/class_sekander_1_1_bullet.html#a12294c6407f43a86cf9d937e54554712", null ],
    [ "Set_X_POS", "da/d68/class_sekander_1_1_bullet.html#af301fa12205fe6c3068fffde3a79168f", null ],
    [ "Set_Y_POS", "da/d68/class_sekander_1_1_bullet.html#a463b5aa21e128bd022c38989cef6280b", null ],
    [ "SetOrigin", "da/d68/class_sekander_1_1_bullet.html#a7b55b501f075c0e647e36d9027c5a6e0", null ],
    [ "SetSpeed", "da/d68/class_sekander_1_1_bullet.html#ad44291d034b112d561ec65d9b57b3fe6", null ],
    [ "Update", "da/d68/class_sekander_1_1_bullet.html#addf91b40d0c5f045226f853615079ac0", null ]
];